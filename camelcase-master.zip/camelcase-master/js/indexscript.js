function redirectToPage() {
  window.location.href = "game.html";
}
function redirectToPage1() {
  window.location.href = "saveTable.html";
}
function redirectToPage2() {
  window.open("Jatekleiras.pdf");
}

// asdfasd   ????  
